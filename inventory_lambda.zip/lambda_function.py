import json
import boto3
import random
import base64
from decimal import Decimal
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('InventoryTable')

# Read index.html content with error handling
try:
    with open('index.html', 'r') as file:
        HTML_CONTENT = file.read()
    print("Successfully loaded index.html")
except Exception as e:
    HTML_CONTENT = "<h1>Error: Could not load index.html</h1>"
    print(f"Failed to load index.html: {str(e)}")

# Read favicon.ico content with error handling
try:
    with open('favicon.ico', 'rb') as file:
        FAVICON_CONTENT = base64.b64encode(file.read()).decode('utf-8')
    print("Successfully loaded favicon.ico")
except Exception as e:
    FAVICON_CONTENT = None
    print(f"Failed to load favicon.ico: {str(e)}")

def populate_inventory():
    item_names = [
        "Laptop", "Mouse", "Keyboard", "Monitor", "Headphones", "Webcam", "Speaker", "Printer", "Router", "Hard Drive","SSD", "USB Drive", "Charger", "Cable", "Docking Station", "Mouse Pad", "Laptop Stand", "Cooling Pad", "Backpack", "Desk Lamp","Chair", "Desk", "Bookshelf", "File Cabinet", "Paper Shredder", "Stapler", "Scissors", "Tape Dispenser", "Pen Holder", "Notebook","Pen", "Pencil", "Marker", "Highlighter", "Eraser", "Ruler", "Calculator", "Sticky Notes", "Paper Clips", "Binder","Folder", "Envelope", "Label Maker", "Whiteboard", "Chalkboard", "Corkboard", "Push Pins", "Magnets", "Dry Erase Markers", "Chalk"
    ]

    items_added = 0
    for i in range(1, 101):
        item_id = f"{i:03d}"
        item_name = random.choice(item_names)
        quantity = random.randint(1, 100)
        price = Decimal(str(round(random.uniform(5.99, 999.99), 2)))

        item = {
            'itemID': item_id,
            'itemName': item_name,
            'quantity': quantity,
            'price': price
        }
        print(f"Attempting to add item {item_id}: {item}")

        try:
            table.put_item(Item=item)
            items_added += 1
            print(f"Successfully added item {item_id}")
        except Exception as e:
            print(f"Failed to add item {item_id}: {str(e)}")
            return {
                'statusCode': 500,
                'headers': {
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': f"Failed to add item {item_id}: {str(e)}"})
            }

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({'message': f"Successfully added {items_added} items to DynamoDB"})
    }

def lambda_handler(event, context):
    try:
        http_method = event['httpMethod']
        path = event.get('path', '/')
        print("Path received:", path)

        # Handle the stage prefix (e.g., /dev)
        if path.startswith('/dev'):
            path = path.replace('/dev', '')

        # Serve the frontend (index.html) for the root path
        if (path == '' or path == '/') and http_method == 'GET':
            print("Serving index.html")
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'text/html',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': HTML_CONTENT
            }

        # Serve favicon.ico
        if path == '/favicon.ico' and http_method == 'GET':
            print("Serving favicon.ico")
            if FAVICON_CONTENT:
                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'image/x-icon',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': FAVICON_CONTENT,
                    'isBase64Encoded': True
                }
            else:
                print("Favicon not found, returning placeholder")
                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'image/x-icon',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': '',
                    'isBase64Encoded': False
                }

        # Populate the database
        if path == '/populate' and http_method == 'GET':
            print("Calling populate_inventory")
            return populate_inventory()

        # Add item
        if path == '/add-item' and http_method == 'POST':
            body = json.loads(event['body'])
            item = {
                'itemID': body['itemID'],
                'itemName': body['itemName'],
                'quantity': body['quantity'],
                'price': Decimal(str(body['price']))
            }
            try:
                table.put_item(Item=item)
                return {
                    'statusCode': 200,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
                        'Access-Control-Allow-Headers': 'Content-Type'
                    },
                    'body': json.dumps({'message': 'Item added successfully', 'item': item})
                }
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': str(e)})
                }

        # Get single item
        if path == '/get-item' and http_method == 'GET':
            item_id = event['queryStringParameters']['itemID']
            try:
                response = table.get_item(Key={'itemID': item_id})
                item = response.get('Item')
                if item:
                    return {
                        'statusCode': 200,
                        'headers': {
                            'Access-Control-Allow-Origin': '*'
                        },
                        'body': json.dumps(item)
                    }
                else:
                    return {
                        'statusCode': 404,
                        'headers': {
                            'Access-Control-Allow-Origin': '*'
                        },
                        'body': json.dumps({'message': 'Item not found'})
                    }
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': str(e)})
                }

        # Get all items
        if path == '/get-all-items' and http_method == 'GET':
            try:
                response = table.scan()
                items = response.get('Items', [])
                return {
                    'statusCode': 200,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'items': items})
                }
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': str(e)})
                }

        # Update item
        if path == '/update-item' and http_method == 'PUT':
            body = json.loads(event['body'])
            item_id = body['itemID']
            try:
                table.update_item(
                    Key={'itemID': item_id},
                    UpdateExpression="set itemName=:n, quantity=:q, price=:p",
                    ExpressionAttributeValues={
                        ':n': body['itemName'],
                        ':q': body['quantity'],
                        ':p': Decimal(str(body['price']))
                    }
                )
                return {
                    'statusCode': 200,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'message': 'Item updated successfully'})
                }
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': str(e)})
                }

        # Delete item
        if path == '/delete-item' and http_method == 'DELETE':
            item_id = event['queryStringParameters']['itemID']
            try:
                table.delete_item(Key={'itemID': item_id})
                return {
                    'statusCode': 200,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'message': 'Item deleted successfully'})
                }
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'headers': {
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({'error': str(e)})
                }

        # If no matching route is found
        print(f"Unsupported path or method: {path}, {http_method}")
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'message': 'Unsupported HTTP method or path'})
        }

    except Exception as e:
        print(f"Unhandled error in lambda_handler: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': f"Internal server error: {str(e)}"})
        }